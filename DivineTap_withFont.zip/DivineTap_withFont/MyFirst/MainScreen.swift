//
//  MainScreen.swift
//  MyFirst
//
//  Created by Paolo Buia on 17/11/2019.
//  Copyright © 2019 Paolo Buia. All rights reserved.
//

import SpriteKit

class MainScreen: SKScene {
    
    override func didMove(to view: SKView) {
        
    }
}
