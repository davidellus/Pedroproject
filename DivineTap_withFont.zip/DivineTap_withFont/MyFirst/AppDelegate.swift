//
//  AppDelegate.swift
//  MyFirst
//
//  Created by Paolo Buia on 08/11/2019.
//  Copyright © 2019 Paolo Buia. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
  var window: UIWindow?

}


